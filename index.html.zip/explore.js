/* explore.js — interactivity, modal, search, contact submit, reveal animation */
document.addEventListener('DOMContentLoaded', () => {

  /* --- AD SPLASH --- */
  const ad = document.getElementById('ad-splash');
  const closeAd = document.getElementById('close-ad');
  if (closeAd) closeAd.addEventListener('click', () => ad.style.display = 'none');

  /* --- MODAL / READ MORE --- */
  const modal = document.getElementById('modal');
  const modalTitle = document.getElementById('modal-title');
  const modalDesc = document.getElementById('modal-desc');
  const closeModalBtn = document.querySelector('.close-modal');

  document.querySelectorAll('.read-more').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const card = e.target.closest('.card');
      // use data-desc (editable in HTML)
      const title = card.dataset.title || card.querySelector('h3').innerText;
      const desc = card.dataset.desc || card.querySelector('p').innerText;
      modalTitle.textContent = title;
      modalDesc.textContent = desc;
      modal.setAttribute('aria-hidden', 'false');
      // focus for accessibility
      closeModalBtn.focus();
    });
  });

  function closeModal() {
    modal.setAttribute('aria-hidden', 'true');
  }
  closeModalBtn.addEventListener('click', closeModal);
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
  modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

  /* --- SEARCH --- */
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', function () {
    const q = this.value.trim().toLowerCase();
    document.querySelectorAll('.card').forEach(card => {
      const title = (card.dataset.title || '').toLowerCase();
      const desc = (card.dataset.desc || '').toLowerCase();
      const visible = title.includes(q) || desc.includes(q);
      card.style.display = visible ? 'block' : 'none';
    });
  });

  /* --- CONTACT FORM (POST to local backend) --- */
  const contactForm = document.getElementById('contactForm');
  const statusEl = document.getElementById('form-status');

  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    statusEl.style.color = 'orange';
    statusEl.textContent = 'Sending...';

    const form = new FormData(contactForm);
    const payload = {
      name: form.get('name'),
      email: form.get('email'),
      message: form.get('message'),
    };

    try {
      // Update URL if your server is on a different host/port
      const res = await fetch('http://localhost:5000/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok) {
        statusEl.style.color = '#7CFC00';
        statusEl.textContent = data.message || 'Message sent! Thank you.';
        contactForm.reset();
      } else {
        statusEl.style.color = 'salmon';
        statusEl.textContent = data.message || 'Failed to send message.';
      }
    } catch (err) {
      statusEl.style.color = 'salmon';
      statusEl.textContent = 'Network error. Is the backend running?';
      console.error(err);
    }
  });

  /* --- Reveal animation for cards (staggered) --- */
  const cards = Array.from(document.querySelectorAll('.card'));
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const idx = cards.indexOf(el);
        el.style.setProperty('--delay', (idx * 0.06) + 's');
        el.classList.add('visible');
        io.unobserve(el);
      }
    });
  }, { threshold: 0.12 });

  cards.forEach(c => io.observe(c));
});
