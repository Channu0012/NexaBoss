// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

// ✨ Setup nodemailer with Gmail
let transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'channupatil299@gmail.com',   // your Gmail
    pass: process.env.GMAIL_PASS        // app password (not your normal Gmail password)
  }
});

/* POST /contact
   payload: { name, email, message }
*/
app.post('/contact', async (req, res) => {
  const { name, email, message } = req.body || {};
  if (!name || !email || !message) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  const mailOptions = {
    from: email,
    to: 'channupatil299@gmail.com', // your inbox
    subject: `New message from ${name} (Explore Page)`,
    text: `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('✅ Email sent successfully');
    return res.json({ message: '✅ Message received. Thank you!' });
  } catch (err) {
    console.error('❌ Email send failed:', err.message);
    return res.status(500).json({ message: 'Failed to send message.' });
  }
});

app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}/contact`));
